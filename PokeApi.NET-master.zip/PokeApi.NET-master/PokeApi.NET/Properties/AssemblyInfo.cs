﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("PokéAPI.NET")]
[assembly: AssemblyDescription("Wrapper for http://www.pokeapi.co/")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("PoroCYon")]
[assembly: AssemblyProduct("PokéAPI.NET")]
[assembly: AssemblyCopyright("Copyright © PoroCYon 2013-2014")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(true)]
[assembly: Guid("029c0647-4f22-4785-9d40-99330752a584")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: CLSCompliant(true)]
